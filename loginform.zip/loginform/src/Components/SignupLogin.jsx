import { useState } from "react"
function Signup(){
    let [State,setState]= useState("Signup")
    const [name,setName] =useState("")
    const [email,setEmail] =useState("")
    const [password,setPassword] =useState("")
    const [lemail,setLemail] =useState("")
    const [pass,setlPassword] =useState("")
    const [arr,setArr]=useState([])

    const signuphandle=()=>{
        let obj={
            name:name,
            email:email,
            pass:password
        }
        setArr([...arr,obj])
        
    }
    const loginhandle=()=>{
        {
            let data=arr.filter((elements)=>{
                return elements.email == lemail && elements.password == pass
            })
            if(data.length>0){
                alert("Login Successfull")
            }
            else{
                alert("Login Unsuccessfull")
            }
        }
    }
    return (
        <div>
            {
                State == "Signup"?
                <div className="mainContainer">
                    <h1 class="mt-3 ms-5 mb-3">Signup</h1>
                    <form>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Name</label>
    <input type="email" onChange={(d)=>setName(d.target.value)} class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
    
  </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail1"  onChange={(d)=>setLemail(d.target.value)} aria-describedby="emailHelp" />
    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
  </div>
  
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" class="form-control"  onChange={(d)=>setlPassword(d.target.value)} id="exampleInputPassword1" />
  </div>
  
  <div class="mb-3 form-check">
    <label class="form-check-label" for="exampleCheck1" onClick={()=>setState('login')}>Do You Have An Accouunt..?</label>
  </div>
  <button type="submit" class="btn btn-primary" onClick={signuphandle}>Signup</button>
</form>
                </div>
                : <div className="mainContainer">
                <h1 class="mt-3 ms-5 mb-3">login Here...</h1>
                <form>
<div class="mb-3">
<label for="exampleInputEmail1" class="form-label">Email address</label>
<input type="email" class="form-control" id="exampleInputEmail1"  onChange={(d)=>setLemail(d.target.value)} aria-describedby="emailHelp" />
<div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
</div>

<div class="mb-3">
<label for="exampleInputPassword1" class="form-label">Password</label>
<input type="password" class="form-control"  onChange={(d)=>setlPassword(d.target.value)} id="exampleInputPassword1" />
</div>

<div class="mb-3 form-check">
<label class="form-check-label" for="exampleCheck1" onClick={()=>setState('Signup')}>Create An Account..?</label>
</div>
<button type="submit" class="btn btn-primary" onClick={loginhandle}>Login</button>
</form>
            </div>
            }
        </div>
    )
}
export default Signup