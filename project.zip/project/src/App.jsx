import logo from './logo.svg';
import './App.css';
import Details from './Components/Details'
function App() {
  return (
    <div className="App">
      <Details/>
      </div>
  );
}

export default App;
