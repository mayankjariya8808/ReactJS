import { useState } from "react";

function Details(){
    const [state,setState]=useState(true)
    const [username,setName]=useState("")
    const [email,setEmail]=useState("")
    const [links,setLinks]=useState("")
    const [exp,setExp]=useState("")
    const [job,setJob]=useState("")
    const [arr,setArr]=useState([])

    const ApplyHandle=()=>{
        let obj={
            username:username,
            email:email,
            links:links,
            exp:exp,
            job:job
        }
        setArr([...arr,obj])
        console.log(arr)
    }
    
    return (
<div>
    {
        state ?

        <div class="container-fluid border mt-5" className="main"> 
<h1 class="mt-3 ms-4 ">Apply For Job</h1>
<div class="container-fluid" className="head">
    <img src="https://i.pinimg.com/originals/6e/a8/c6/6ea8c68dfa924bc2e6a9abe3e473087a.gif" alt="" />
</div>
        <div class="container-fluid p-5" className="bodyy">
        <div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">@</span>
  <input type="text" class="form-control" onChange={(d)=>setName(d.target.value)} placeholder="Username" aria-label="Username" aria-describedby="basic-addon1" />
</div>

<div class="input-group mb-3">
  <input type="text" class="form-control" placeholder="Enter Your Mail ID" onChange={(d)=>setEmail(d.target.value)} aria-label="Recipient's username" aria-describedby="basic-addon2" />
  <span class="input-group-text" id="basic-addon2">@example.com</span>
</div>

<label for="basic-url" class="form-label">Your Social Links</label>
<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon3">https://example.com/users/</span>
  <input type="text" class="form-control"  onChange={(d)=>setLinks(d.target.value)} id="basic-url" aria-describedby="basic-addon3" />
</div>

<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">Experiance</span>
  <input type="text" class="form-control" onChange={(d)=>setExp(d.target.value)} placeholder="Username" aria-label="Username" aria-describedby="basic-addon1" />
</div>

<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">Apply For</span>
  <input type="text" class="form-control" onChange={(d)=>setJob(d.target.value)} placeholder="Username" aria-label="Username" aria-describedby="basic-addon1" />
</div>
<button class="btn btn-outline-warning" onClick={ApplyHandle}>Apply Now</button>
<button class="btn btn-outline-dark mt-3" onClick={()=>setState(false)}>Show Application</button>

        </div>
</div>: 
<div>
<table class="table table-striped border">
                        <tr>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Links</th>
                            <th>Experiance</th>
                            <th>Applay For</th>
                            
                        </tr>
                        {
                            arr.map((val)=>{

                                return(
                                <tr>
                                    <td>{val.username}</td>
                                    <td>{val.email}</td>
                                    <td>{val.links}</td>
                                    <td>{val.exp}</td>
                                    <td>{val.job}</td>
                                </tr>
                                )
                            })
                        }
                    </table>
                    <button class="btn btn-outline-dark float-end" onClick={()=>setState(true)}>Add Application</button>
                
        
</div>
    }
</div>
    )
}
export default Details